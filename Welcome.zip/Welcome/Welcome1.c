 /* Welcome.c by Joe Ermatinger 11/16/2018 */
 /* This program asks basic information about a student using several strings. */
 
 #include <stdio.h>
 #include <string.h>
 #include "fixgets.h"
 
 int main (void)
 {
	char firstName [11];
	char middleInitial [2];
	char lastName [16];
	char studentNumber [7];
	char highSchoolName [21];
	char message [16];
	
	printf("Welcome Student Application by Joe Ermatinger");

	printf("\n\nFirst Name?\t");
	fixgets(firstName,11,stdin);
	
	printf("\n\nMiddle Initial?\t");
	fixgets(middleInitial,2,stdin);
	
	printf("\n\nLast Name?\t");
	fixgets(lastName,16,stdin);
	
	printf("\n\nStudent Number?\t");
	fixgets(studentNumber,7,stdin);
	
	printf("\n\nName of High School?\t");
	fixgets(highSchoolName,21,stdin);
	
	scramble[x] = Lname[0];
	x++;
	scramble[x] = Lname[1];
	x++;
	scramble[x] = Fname[0];
	x++;
	scramble[x] = Fname[1];
	x++;
	scramble[x] = '\0';

	printf("%s\n", salutation);
	printf("%s\n", scramble);

	
	return 0;
 }
 
 
	
	
	
	