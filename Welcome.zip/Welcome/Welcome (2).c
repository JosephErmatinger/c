/* Welcome.c by Joe Ermatinger 11/16/2018 */
 /* This program asks basic information about a student using several strings. A student's first and last name, middle initial
 student number,and High School name is gathered to create a 10 character password and message that utilizes the strcpy and strcat functions. 
 Input is gathered with the keyboard via the fixgets functions and displayed to the screen via printf */
 
 /*****************************************************************************************************/
 /* Header Files */
 
 #include <stdio.h>
 #include <string.h>
 #include "fixgets.h" // from Harry W. Brown Circa 1986
 
 /*****************************************************************************************************/
 /* Start of Main */
 
 int main (void) 
 {
	char fName [11]; // Declarations of Strings
	char mInitial [2];
	char lName [16];
	char sNum [7];
	char hsName [21];
	char Message [100];
	char Password [11];
	int x = 0;
	
/*****************************************************************************************************/
/* Input Section */
	
	printf(" Welcome Student Application by Dan Aull");

	printf("\n\n First Name?\t\t"); //First Name Entry
	fixgets(fName,11,stdin);
	
	printf("\n\n Middle Initial?\t"); // Middle Initial Entry
	fixgets(mInitial,2,stdin);
	
	printf("\n\n Last Name?\t\t"); // Last Name Entry
	fixgets(lName,16,stdin);
	
	printf("\n\n Student Number?\t"); // Student Number Entry
	fixgets(sNum,7,stdin);
	
	printf("\n\n Name of High School?\t"); // High School Name Entry
	fixgets(hsName,21,stdin);
	
/*****************************************************************************************************/
/* Processing Section That Combines Strings*/
	
	strcpy(Message, "\n\n\n Welcome to MCC, ");
	strcat(Message, fName);
	strcat(Message, " ");
	strcat(Message, mInitial);
	strcat(Message, ". ");
	strcat(Message, lName);
	strcat(Message, " #");
	strcat(Message, sNum);
	strcat(Message, " from ");
	strcat(Message, hsName);
	strcat(Message, "!");
	
/*****************************************************************************************************/
/* Processing Section That Creates Password. The Password is comprised of multiple elements taken from sNum, fName, mInitial, and lName.
   The first two characters are gathered from the student number, the second two from the first name, then a middle initial.
   After that, two more are gathered from the last name and the final three are gathered from first name, student number, and last name. 
   A null is used to finalize the string. A counter is used to add a level of randomness to the password not otherwise provided. */

	Password[x] = sNum[0];
	x++;
	Password[x] = sNum[1];
	x++;
	Password[x] = fName[0];
	x++;
	Password[x] = fName[1];
	x++;
	Password[x] = mInitial[0];
	x++;
	Password[x] = lName[0];
	x++;
	Password[x] = lName[1];
	x++;
	Password[x] = fName[3];
	x++;
	Password[x] = sNum[3];
	x++;
	Password[x] = lName[3];
	x++;
	Password[x] = '\0';
	
/*****************************************************************************************************/
/* Output Section */	
	
	printf("%s\n", Message);
	printf("\n Your Password is %s", Password); 
	
	
/*****************************************************************************************************/
/* End of Main */	
	
	return 0;
 }
 
 
	
	
	
	